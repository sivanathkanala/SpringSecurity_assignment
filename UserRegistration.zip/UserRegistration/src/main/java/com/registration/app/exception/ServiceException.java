package com.registration.app.exception;

public class ServiceException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiceException(String string) {
		super(string);
	}
}
